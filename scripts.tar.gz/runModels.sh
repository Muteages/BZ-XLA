#!/bin/bash
set -e

TARGET_MODEL="$1"
RUN_MODE="$2"   # optional: "save"

MODELS_LIST="./scripts/models.list"
SERVER_SCRIPT="./server"
CHECK_SCRIPT="./scripts/test.sh"
CHECK_RESULT="./check_result.txt"

> "$CHECK_RESULT"

# Config
PORT_A=8500 # You can change it to any free port
PORT_B=8501 # You can change it to any free port
export PORT_A PORT_B
BATCH_SIZE=10
ABS_TOL=1e-7
REL_TOL=1e-6

# XLA control: 0=off, 1=on
# Normal mode: test both (0 and 1)
# Save mode: only XLA=1 and CLIENT_ARG=save
ENABLE_XLA_VALUES=(0 1)
FORCE_CLIENT_ARG=""

if [[ -n "$RUN_MODE" ]]; then
  case "$RUN_MODE" in
    save)
      ENABLE_XLA_VALUES=(1)
      FORCE_CLIENT_ARG="save"
      ;;
    *)
      echo "[ERROR] Unknown mode: '$RUN_MODE'. Supported: save"
      exit 1
      ;;
  esac
fi

stop_server() {
    if [[ -n "$SERVER_PID" ]]; then
        echo "Stopping server (PID $SERVER_PID)..."
        kill "$SERVER_PID" 2>/dev/null || true
        wait "$SERVER_PID" 2>/dev/null || true
        SERVER_PID=""
    fi
}

while read -r MODEL_PATH; do
    # Generate short name for server
    MODEL_NAME_SHORT=$(echo "$MODEL_PATH" | sed -E 's/.*model_([a-zA-Z0-9_-]+).*/\1/')

    if [[ -n "$TARGET_MODEL" && "$MODEL_NAME_SHORT" != "$TARGET_MODEL" ]]; then
        continue
    fi

    echo "=============================="
    echo "Processing model: $MODEL_PATH"
    export model="$MODEL_PATH"

    for XLA in "${ENABLE_XLA_VALUES[@]}"; do
        echo ">>> Running with XLA=$XLA"
        export ENABLE_XLA="$XLA"

        # Determine client argument based on XLA (or forced mode)
        if [[ -n "$FORCE_CLIENT_ARG" ]]; then
            CLIENT_ARG="$FORCE_CLIENT_ARG"
        else
            if [[ "$XLA" -eq 0 ]]; then
                CLIENT_ARG="save"
            else
                CLIENT_ARG="check"
            fi
        fi

        # Make sure ports are free
        for PORT in $PORT_A $PORT_B; do
            if lsof -i :"$PORT" -sTCP:LISTEN >/dev/null; then
                echo "Port $PORT is in use. Killing conflicting processes..."
                fuser -k "$PORT"/tcp || true
                sleep 1
            fi
        done

        # Start server in background
        bash "$SERVER_SCRIPT" &
        SERVER_PID=$!
        echo "Server started with PID $SERVER_PID"
        sleep 5  # wait for server to be ready

        # Run client script
        echo "Running client script with MODEL_NAME=${MODEL_NAME_SHORT}, XLA=$XLA, CLIENT_ARG=$CLIENT_ARG"
        set +e
        BATCH_SIZE=${BATCH_SIZE} USING_PORT_REST_API=${PORT_B} MODEL_NAME=${MODEL_NAME_SHORT} FLAGS="--abs-tol ${ABS_TOL} --rel-tol ${REL_TOL}" \
            bash "$CHECK_SCRIPT" "$CLIENT_ARG"
        STATUS=$?
        set -e

        if [[ $STATUS -eq 0 ]]; then
            PASS_FLAG="check passed"
        else
            PASS_FLAG="Check failed"
        fi

        if [[ "$XLA" -eq 1 ]]; then
          echo "$MODEL_NAME_SHORT $PASS_FLAG" >> "$CHECK_RESULT"
        fi

        stop_server
        echo "Finished model $MODEL_PATH with XLA=$XLA"
    done

done < "$MODELS_LIST"

if [[ -n "$TARGET_MODEL" ]]; then
    if ! sed -E 's/.*model_([a-zA-Z0-9_-]+).*/\1/' "$MODELS_LIST" | grep -qx "$TARGET_MODEL"; then
        echo "[ERROR] Model '$TARGET_MODEL' not found in $MODELS_LIST"
        exit 1
    fi
fi

echo "All tests done. Summary saved to $CHECK_RESULT"
