import tensorflow.compat.v1 as tf
import tensorflow as tf2
import numpy as np


# ------------------------------
# This dictionary defines common TensorFlow operations for testing
# Each entry includes:
#   - "shape": the placeholder/input shape
#   - "fn": the function that applies the operation to the input tensor
# ------------------------------
OPS_META = {
    # Basic elementwise math operations
    "STATIC": {
        "shape": [None,10],
        "fn": lambda x: tf.add(
            x,
            10.0
        )
    },
    "TF": {
        "shape": [None, 1],
        "fn": lambda x: (
            tf.pow(
                tf.concat([
                    tf.multiply(
                        tf.concat([x, x], axis=1),
                        2.0                       
                    ),
                    x                          
                ], axis=1),
                3.0
            )
        )
    },
    "SCALAR": {
        "shape": [None],
        "fn": lambda x: tf.stack([
            tf.strided_slice(x, [0], [1])[0],  # float32
            tf.cast(
                tf.reduce_max(tf.range(tf.shape(x)[0])), 
                tf.float32
            )
        ])
    },
    "SPLIT": {
        "shape": [None, 13, 13],
        "fn": lambda x: split_check(x),
    },
    "ADD_SAME": {"shape": [None, 10], "fn": lambda x: tf.add(tf.reshape(x, [-1, 2]), 1.5)},
    "ADD_BCAST_LAST": {"shape": [None, 13, 13], "fn": lambda x: x + tf.ones([1, 13], tf.float32)},
    "ADD_SCALAR": {"shape": [None, 13, 13], "fn": lambda x: x + tf.ones([1, 1, 1], tf.float32)},
    "MUL_SAME": {"shape": [None, 13, 13], "fn": lambda x: x * tf.fill(tf.shape(x), 1.5)},
    "MUL_BCAST_LAST": {"shape": [None, 13, 13], "fn": lambda x: x * tf.ones([1, 13], tf.float32)},
    "MUL_SCALAR": {"shape": [None, 13, 13], "fn": lambda x: x * tf.ones([1, 1, 1], tf.float32)},
    "FLOORDIV": {"shape": [10, 10], "fn": lambda x: tf.math.floordiv(x, tf.fill(tf.shape(x), 1.5))},
    "DIV_SAME": {"shape": [None, 13, 13], "fn": lambda x: x / (tf.ones_like(x) + 1e-5)},
    "DIV_BCAST_LAST": {"shape": [None, 13, 13], "fn": lambda x: x / (tf.ones([1, 13], tf.float32) + 1e-5)},
    "DIV_SCALAR": {"shape": [None, 13, 13], "fn": lambda x: x / (tf.ones([1, 1, 1], tf.float32) + 1e-5)},
    #"MOD": {"shape":[None,13,13], "fn": lambda x: tf.math.mod(x, 2.0)},
    #"NEG": {"shape":[None,13,13], "fn": lambda x: -x},
    "ABS": {"shape":[None,13,13], "fn": lambda x: tf.abs(x)},
    "POW_SAME": {"shape": [None, 13, 13], "fn": lambda x: tf.math.pow(x, tf.ones_like(x) * 2.0)},
    "POW_BCAST_LAST": {"shape": [None, 13, 13], "fn": lambda x: tf.math.pow(x, tf.ones([1, 13], tf.float32) * 2.0)},
    "POW_SCALAR_TENSOR": {"shape": [None, 13, 13], "fn": lambda x: tf.math.pow(x, tf.ones([1, 1, 1], tf.float32) * 2.0)},
    #"SQRT": {"shape":[None,13,13], "fn": lambda x: tf.sqrt(tf.abs(x)+1e-5)},
    "EXP": {"shape":[None,13,13], "fn": lambda x: tf.exp(x)},
    "LOG": {"shape":[None,13,13], "fn": lambda x: tf.math.log(tf.abs(x)+1e-5)},
    "FILL": {"shape": [None, 10, 10], "fn": lambda x: tf.fill([tf.shape(x)[0], 10, 10], 1.0)},
    "FILL2": {"shape": [None, 10, 10], "fn": lambda x: tf.fill(tf.shape(x), 1.0)},
    "RANGE": {"shape": [None, 2, 2], "fn": lambda x: tf.range(tf.shape(x)[0])},
    
    # Activations / non-linear functions
    "RELU": {"shape":[None,13,13], "fn": tf.nn.relu},
    "LEAKY_RELU": {"shape":[None,13,13], "fn": lambda x: tf.nn.leaky_relu(x)},
    "ELU": {"shape":[None,13,13], "fn": lambda x: tf.nn.elu(x)},
    "SIGMOID": {"shape":[None,13,13], "fn": lambda x: tf.nn.sigmoid(x)},
    "TANH": {"shape":[None,13,13], "fn": lambda x: tf.nn.tanh(x)},
    "SOFTMAX": {"shape":[None,13,13], "fn": lambda x: tf.nn.softmax(x, axis=-1)},
    
    # Linear algebra operations
    "MATMUL": {"shape":[None,16], "fn": lambda x: tf.matmul(x, tf.ones([16,16], tf.float32))},
    "BATCH_MATMUL": {"shape":[None,16,16], "fn": lambda x: tf.matmul(x, tf.ones([16,16], tf.float32))},
    "TRANSPOSE": {"shape":[13,None,13], "fn": lambda x: tf.transpose(x, perm=[1,0,2])},
    "DIAG": {"shape":[None,13], "fn": lambda x: tf.linalg.diag(tf.abs(x))},
    
    # Reduction operations
    "REDUCE_SUM": {"shape":[None,13,13], "fn": lambda x: tf.reduce_sum(x, axis=0)},
    "REDUCE_MEAN": {"shape":[None,13,13], "fn": lambda x: tf.reduce_mean(x, axis=0, keepdims=True)},
    "REDUCE_MAX": {"shape":[None,13,13], "fn": lambda x: tf.reduce_max(x, axis=-1)},
    "REDUCE_MIN": {"shape":[None,13,13], "fn": lambda x: tf.reduce_min(x, axis=-1)},
    "ARGMAX": {"shape":[None,13,13], "fn": lambda x: tf.argmax(x, axis=-1)},
    "ARGMIN": {"shape":[None,13,13], "fn": lambda x: tf.argmin(x, axis=-1)},
    
    # Tensor manipulation operations

    "RESHAPE": {"shape":[None,13,13], "fn": lambda x: tf.reshape(x, [-1, 13])},
    "RESHAPE2": {"shape":[None,13,13], "fn": lambda x: tf.multiply(tf.reshape(tf.add(x, 1.5), [-1, 13]), 1.5)},
    "RESHAPE22": {"shape":[None,2], "fn": lambda x: tf.multiply(tf.reshape(x, [-1,4]), 1.5)},
    "RESHAPE23": {"shape":[None,2, 2], "fn": lambda x: tf.multiply(tf.reshape(x, [-1,4]), 1.5)},
    
    
    "RESHAPE3": {"shape":[None,13,13], "fn": lambda x: tf.transpose(tf.reshape(x, [-1, 13]), [1, 0])},
    "RESHAPE4": {
        "shape": [None, 5, 5],
        "fn": lambda x: tf.add(
            tf.reshape(
                tf.multiply(
                    tf.reshape(x, [-1, 5]),
                    2.4
                ),
                [-1, 25]
            ),
            1.5
        )
    },
    "RESHAPE5": {
        "shape": [
            [5, 2],
            [None, 5, 5]
        ],
        "fn": lambda x1, x2: tf.matmul(
            tf.reshape(x1, [2,5]),          # static
            tf.reshape(x2, [-1,5]),         # dynamic
            transpose_b=True
        )
    },

    # "RESHAPE4": {
    #     "shape": [None, 10, 10],
    #     "fn": lambda x: tf.reshape(
    #         tf.multiply(
    #             tf.reshape(
    #                 tf.add(lib.pass_dynamic_dimension(x, tf.shape(x)),10.0),
    #                 [-1, 5]
    #             ),
    #             2.0
    #         ),
    #         [10, -1]
    #     )
    # },

    "SQUEEZE": {"shape":[None,13,13,1], "fn": lambda x: tf.squeeze(x, -1)},
    "EXPAND_DIMS": {"shape":[None,13,13], "fn": lambda x: tf.expand_dims(x,-1)},
    "CONCAT": {"shape":[None, 10], "fn": lambda x: tf.add(tf.concat([x,x], axis=0), 1.5)},
    "STACK": {"shape":[None, 13], "fn": lambda x: tf.stack([x], axis=0)},
    "SLICE": {"shape":[None,5,13], "fn": lambda x: tf.slice(x, begin=tf.constant([0, 0, 0], dtype=tf.int32), size=tf.constant([-1, 5, 3], dtype=tf.int32))},
    "SLICE_STRIDED": {"shape": [None, 13, 13], "fn": lambda x: x[:, ::2, ::2],},
    "SLICE_DYNAMIC": {
        "shape": [None, 13, 13],
        "fn": lambda x: x[:, :tf.shape(x)[1]//2, :]
    },
    "PAD": {"shape":[None,15,15], "fn": lambda x: tf.pad(x, [[0,tf.maximum(0, 1000 - tf.shape(x)[0])],[0,0],[0,0]])},
    "RESIZE": {"shape": [None, 13, 13, 1], "fn": lambda x: tf.image.resize(x, [20, 20], method=tf.image.ResizeMethod.BILINEAR),},
    "GATHER": {"shape":[None,2,13], "fn": lambda x: tf.gather(x, indices=[0,1], axis=1)},
    "GATHER_ND": {"shape":[None,2,2], "fn": lambda x: tf.gather_nd(x, [[0,1,0],[1,1,1]])},
    "ONE_HOT": {"shape":[None,13,13], "fn": lambda x: tf.one_hot(tf.cast(x, tf.int32), depth=10)},
    "REPEAT": {"shape": [None, 2, 2], "fn": lambda x: tf.repeat(x, repeats=2, axis=0)},
    "REVERSE": {"shape": [None, 13, 13], "fn": lambda x: tf.reverse(x, axis=[0])},
    "UNIQUE": {"shape": [None], "fn": lambda x: tf.add(tf.unique(x)[0], 1)},
    "UNIQUE1": {"shape": [None], "fn": lambda x: tf.add(tf.unique(x)[1], 1)},
    # Convolution
    "CONV2D": {
        "shape":[None,13,13,1],
        "fn": lambda x: tf.nn.conv2d(
            x,
            filters=tf.constant(
                np.array(
                    [[[[1]], [[0]], [[-1]]],
                     [[[1]], [[0]], [[-1]]],
                     [[[1]], [[0]], [[-1]]]],
                    dtype=np.float32,
                )
            ),
            strides=[1,1,1,1],
            padding="VALID"
        )
    },

    # Testcases related to batch dimension
    "BATCH_REVERSE": {
        "shape": [None, 13, 13], 
        "fn": lambda x: tf.reverse(x, axis=[0])
    },
    "BATCH_TILE": {
        "shape": [None, 13, 13],
        "fn": lambda x: tf.tile(x, [2, 1, 1])[0:tf.shape(x)[0]]
    },
    "BATCH_REPEAT": {
        "shape": [None, 13, 13],
        "fn": lambda x: tf.repeat(x, repeats=2, axis=0)[0:tf.shape(x)[0]]
    },
    "BATCH_STACK_SLICE": {
        "shape": [None, 13, 13],
        "fn": lambda x: tf.slice(
            tf.stack([x, x], axis=0),
            begin=[0, 0, 0, 0],
            size=[1, -1, -1, -1]
        )[0]
    },
    "BATCH_CONCAT_SLICE": {
        "shape": [None, 12, 12],
        "fn": lambda x: tf.slice(
            tf.concat([x, x], axis=0),
            begin=[0, 0, 0],
            size=tf.shape(x)
        )
    },
    "BATCH_CONCAT_SLICE_FIXED": {
        "shape": [None, 13, 13],
        "fn": lambda x: tf.slice(
            tf.concat([x, tf.ones([3, 13, 13], tf.float32)], axis=0),  # second tensor has batch=3
            begin=[0, 0, 0],
            size=tf.shape(x)
        )
    },
    "BATCH_EXPAND_SQUEEZE": {
        "shape": [None, 13, 13],
        "fn": lambda x: tf.squeeze(
            tf.expand_dims(x, axis=0),
            axis=0
        )
    },
    "BATCH_RESHAPE_RESTORE": {
        "shape": [None, 13, 13],
        "fn": lambda x: tf.reshape(
            tf.reshape(x, [1, -1, 13, 13]),
            tf.shape(x)
        )
    },
    "BATCH_TRANSPOSE_RESTORE": {
        "shape": [None, 13, 13],
        "fn": lambda x: tf.transpose(
            tf.transpose(x, perm=[1, 0, 2]),
            perm=[1, 0, 2]
        )
    },
    "BATCH_GATHER_RESTORE": {
        "shape": [None, 13, 13],
        "fn": lambda x: tf.gather(
            tf.gather(x, tf.range(tf.shape(x)[0]), axis=0),
            tf.range(tf.shape(x)[0]),
            axis=0
        )
    },
    "BATCH_STRESS_PIPELINE": {
        "shape": [None, 13, 13],
        "fn": lambda x: tf.squeeze(
            tf.slice(
                tf.concat(
                    [tf.expand_dims(x, 0), tf.expand_dims(x, 0)],
                    axis=0
                ),                         # [2, B, 13, 13]
                begin=[0, 0, 0, 0],
                size=[1, -1, -1, -1]
            ),
            axis=0
        )
    },
    "BATCH_REDUCE_EXPAND": {
        "shape": [None, 13, 13],
        "fn": lambda x: tf.broadcast_to(
            tf.reduce_mean(x, axis=0, keepdims=True),
            tf.shape(x)  
        )
    },

    # Extra
    # "SPARSE_SEGMENT_SUM": {
    #     "shape": [None, 13, 13],
    #     "fn": lambda x: tf.sparse.to_dense(
    #         tf.sparse.segment_sum(
    #             tf.sparse.from_dense(x),
    #             segment_ids=tf.zeros(tf.shape(x)[0], tf.int32)
    #         )
    #     )
    # },
    # "SPARSE_RESHAPE": {
    #     "shape": [None, 13, 13],
    #     "fn": lambda x: tf.sparse.to_dense(
    #         tf.sparse.reshape(
    #             tf.sparse.from_dense(x),
    #             tf.cast([tf.shape(x)[0], 169], tf.int32)
    #         )
    #     )
    # },
    # "PARALLEL_DYNAMIC_STITCH": {
    #     "shape": [None, 13, 13],
    #     "fn": lambda x: tf.parallel_dynamic_stitch(
    #         [tf.range(tf.shape(x)[0])],
    #         [x]
    #     )
    # },
    "DYNAMIC_PARTITION": {
        "shape": [None, 13, 13],
        "fn": lambda x: (
            lambda y: tf.dynamic_partition(
                y,
                partitions=tf.zeros(tf.shape(y)[0], dtype=tf.int32),
                num_partitions=12
            )[0]
        )(tf.concat([x, tf.ones([3, 13, 13], tf.float32)], axis=0))
    },
    "UNIQUE_DATA": {
        "shape": [None, 32],
        "fn": lambda x: unique_mixed(x)[0],
    },

    "UNIQUE_IDX": {
        "shape": [None, 32],
        "fn": lambda x: unique_mixed(x)[1],
    },
    "UNIQUE_CASE": {
        "shape": [
            [None, 36],
            [None, 10],
        ],
        "fn": lambda inputA, embedding_data: unique1(
            inputA, embedding_data, concat_axis=0
        ),
    },
    # "DYNAMIC_PARTITION2": {
    #     "shape": [13, None, 13],
    #     "fn": lambda x: (
    #         lambda y: tf.dynamic_partition(
    #             y,
    #             partitions=tf.zeros(tf.shape(y)[0], dtype=tf.int32),
    #             num_partitions=12
    #         )[0]
    #     )(tf.concat([x, tf.ones([13, 3, 13], tf.float32)], axis=1))
    # },
    "DYNPART_GATHER_STITCH": {
        "shape": [None, 32],
        "fn": lambda x: dynpart_gather_stitch_from_single_input(x, feature_dim=16, num_partitions=12, offset_second=True),
    },
    "GATHER_RESHAPE_30": {
        "shape": [
            [None, 1],        # inputA
            [262145, 10],     # embedding_data
        ],
        "fn": lambda inputA, embedding_data: gather_reshape_to_30(inputA, embedding_data),
    },
    "RESHAPE_TEST1": {
        "shape": [
            [None],              # input0: indices (float32 placeholder -> cast to int32)
            [262145, 3, 10],     # input1: embedding_data (float32)
        ],
        "fn": lambda indices, embedding_data: gather_3x10_then_reshape30(indices, embedding_data),
    }
    # "CONCAT_CHAIN": {
    #     "shape": [None, 5, 5],
    #     "fn": lambda x: tf.concat(
    #         [x, tf.concat([x, x], axis=0)],
    #         axis=0
    #     )
    # },
    # "CONCAT_FIXED_CHAIN": {
    #     "shape": [None, 5, 5],
    #     "fn": lambda x: concat_fixed_chain(x)
    # }
    # "SPARSE_SEGMENT_MEAN": {
    #     "shape": [None, 13, 13],
    #     "fn": lambda x: tf.sparse.to_dense(
    #         tf.sparse.segment_mean(
    #             tf.sparse.from_dense(x),
    #             indices=tf.range(tf.shape(x)[0]),
    #             segment_ids=tf.zeros(tf.shape(x)[0], tf.int32)
    #         )
    #     )
    # }

    # ==========================================
    # [OPTIONAL] Logical / comparison operations
    # ========================================== 
    #"GREATER": {"shape":[None,13,13], "fn": lambda x: tf.greater(x,0)},
    #"LESS": {"shape":[None,13,13], "fn": lambda x: tf.less(x,0)},
    #"EQUAL": {"shape":[None,13,13], "fn": lambda x: tf.equal(x,0)},
    #"LOGICAL_AND": {"shape":[None,13,13], "fn": lambda x: tf.logical_and(x>0, x<1)},
    #"LOGICAL_OR": {"shape":[None,13,13], "fn": lambda x: tf.logical_or(x>0, x<1)},

    # Shape-related
    # "SHAPE": {"shape":[None,13,13], "fn": tf.shape},
    # "RANK": {"shape":[None,13,13], "fn": tf.rank}

}


def dynpart_gather_stitch_from_single_input(
    x,
    feature_dim=16,
    num_partitions=12,
    offset_second=True,
):
    # x: [B, 2F]
    Bhalf = tf.identity(x[:, feature_dim:2*feature_dim], name="identity_data")  # [B, F]
    batch = tf.shape(x, out_type=tf.int32)[0]
    X = tf.range(batch, dtype=tf.int32, name="X_range")

    # ---------------- Group 1: mod -> dynpart(indices) -> gather ----------------
    part_ids_mod = tf.math.floormod(X, num_partitions, name="part_ids_mod")  # [B]
    indices_mod_list = tf.dynamic_partition(
        data=X, partitions=part_ids_mod, num_partitions=num_partitions, name="DP_indices_mod"
    )  # 12x [Ni]

    data_gather_list = [
        tf.gather(Bhalf, indices_mod_list[i], axis=0, name=f"GATHER_V2_{i}")
        for i in range(num_partitions)
    ]  # 12x [Ni, F]

    # ---------------- Group 2: div -> dynpart(data) (+ matching dynpart(indices)) ----------------
    block = tf.maximum((batch + (num_partitions - 1)) // num_partitions, 1, name="block")  # ceil(B/12)
    part_ids_div = tf.minimum(X // block, num_partitions - 1, name="part_ids_div")         # clamp to 0..11
    part_ids_div = tf.cast(part_ids_div, tf.int32, name="part_ids_div_cast")

    # This is the "real" data dynamic_partition you want to feed into stitch
    data_div_list = tf.dynamic_partition(
        data=Bhalf, partitions=part_ids_div, num_partitions=num_partitions, name="DP_data_div"
    )  # 12x [Mi, F]

    # Matching indices for those partitions (needed by stitch)
    indices_div_list = tf.dynamic_partition(
        data=X, partitions=part_ids_div, num_partitions=num_partitions, name="DP_indices_div"
    )  # 12x [Mi]

    if offset_second:
        indices_div_list = [idx + batch for idx in indices_div_list]  # adds you saw

    # ---------------- ParallelDynamicStitch: (gather outputs) + (dynpart outputs) ----------------
    stitch_indices = list(indices_mod_list) + list(indices_div_list)  # 24 branches
    stitch_data = list(data_gather_list) + list(data_div_list)        # 24 branches

    y = tf2.raw_ops.ParallelDynamicStitch(indices=stitch_indices, data=stitch_data, name="stitched")
    return y  # [2B, F] if offset_second=True else [B,F] but may collide

def concat_fixed_chain(x):
    fixed = tf.fill([3, 5, 5], 1.5)

    x1 = tf.concat([x, fixed], axis=0)
    x2 = tf.concat([x1, fixed], axis=0)
    x3 = tf.concat([x2, fixed], axis=0)

    return x3

def unique_mixed(inputA):
    # inputA: 2D tensor, e.g. [B, W]
    begin = tf.constant([0, 0], dtype=tf.int32)
    end   = tf.stack([1, tf.shape(inputA, out_type=tf.int32)[1]], axis=0)  # 取第一行 + 全部列
    strides = tf.constant([1, 1], dtype=tf.int32)

    slice_out = tf.raw_ops.StridedSlice(
        input=inputA,
        begin=begin,
        end=end,
        strides=strides,
        begin_mask=0,
        end_mask=0,
        ellipsis_mask=0,
        new_axis_mask=0,
        shrink_axis_mask=0,
        name="slice_out"
    )  # [1, W]

    sub_out = tf.subtract(slice_out, tf.constant(1.0, dtype=slice_out.dtype), name="sub_out")
    data_1d = tf.reshape(sub_out, [-1], name="data_1d")  # [W]

    width = tf.shape(slice_out, out_type=tf.int32)[1]  # W
    prod_in = tf.reshape(width, [1, 1], name="prod_in_reshape")
    prod_out = tf2.raw_ops.Prod(input=prod_in, axis=1, keep_dims=False, name="prod_out")  # [1], int32

    merged = tf.reshape(data_1d, prod_out, name="merge_reshape")
    res = tf.unique(merged, name="unique_out")
    return res

def unique_gather(idx, embedding_data, concat_axis=0):
    if idx.dtype not in (tf.int32, tf.int64):
        idx = tf.cast(idx, tf.int32, name="idx_cast_int32")

    axis0 = tf.constant(0, tf.int32, name="axis0")

    gA = tf.raw_ops.GatherV2(params=embedding_data, indices=idx, axis=axis0, name="GatherV2A")
    gB = tf.raw_ops.GatherV2(params=gA,           indices=idx, axis=axis0, name="GatherV2B")

    out = tf.raw_ops.ConcatV2(
        values=[gA, gB],
        axis=tf.constant(concat_axis, tf.int32),
        name="ConcatV2_after_gathers"
    )
    return out

def unique1(inputA, embedding_data, concat_axis=0):
    _, idx = unique_mixed(inputA)
    return unique_gather(idx, embedding_data, concat_axis=concat_axis)

def gather_reshape_to_30(inputA, embedding_data):
    idx = tf.reshape(inputA, [-1], name="idx_flat")                 # [N]
    idx = tf.cast(idx, tf.int32, name="idx_cast")                   # [N] int32
    idx = tf.math.floormod(idx, tf.constant(262145, tf.int32), name="idx_mod")  # [N] in range

    # 2) GatherV2(axis=0): output shape [N, 10]
    gathered = tf.raw_ops.GatherV2(
        params=embedding_data,
        indices=idx,
        axis=tf.constant(0, tf.int32),
        name="GatherV2"
    )  # [N, 10]

    # 3) Reshape: shape<2> = [-1, 30]  -> output [?, 30]
    reshaped = tf.reshape(gathered, [-1, 30], name="Reshape_to_30")
    return reshaped

def gather_3x10_then_reshape30(indices_f32, embedding_data):

    # indices must be int32/int64 for GatherV2
    idx = tf.cast(tf.reshape(indices_f32, [-1]), tf.int32, name="idx_i32")  # [N]

    gathered = tf.raw_ops.GatherV2(
        params=embedding_data,                 # [262145, 3, 10]
        indices=idx,                           # [N]
        axis=tf.constant(0, tf.int32),
        name="GatherV2"
    )  # [N, 3, 10]

    n = tf.shape(gathered, out_type=tf.int32)[0]

    # Keep the “two reshapes” style similar to what you saw in HLO
    r1 = tf.reshape(gathered, [n, 3, 10], name="reshape_26")  # [N,3,10]
    r2 = tf.reshape(r1, [n, 30], name="reshape_53")           # [N,30]
    return r2


def split_check(x):
    bsz = tf.shape(x)[0]
    first = bsz // 3
    second = bsz - first

    x1, x2 = tf.split(x, [first, second], axis=0)    
    y1 = x1 + 2.0
    y2 = x2 - 3.0
    z = tf.concat([y1, y2], axis=0)
    return z