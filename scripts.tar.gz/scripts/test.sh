#! /bin/bash

unset http_proxy

if [ -v VARIABLES ]; then
    source $VARIABLES
else
    MISSING_PARAMETERS=false
    MISSING_PARAMETER=""
    if [ ! -v USING_PORT_REST_API ]; then
        MISSING_PARAMETER+=' \t * USING_PORT_REST_API\n'
        MISSING_PARAMETERS=true
    fi

    if [ ! -v MODEL_NAME ]; then
        MISSING_PARAMETER+=' \t * MODEL_NAME\n'
        MISSING_PARAMETERS=true
    fi

    if [ ! -v BATCH_SIZE ]; then
        MISSING_PARAMETER+=' \t * BATCH_SIZE\n'
        MISSING_PARAMETERS=true
    fi

    if $MISSING_PARAMETERS; then
        echo -n "These parameter/s are missing. Please define them and "
        echo "run the script again."
        printf "%b" "$MISSING_PARAMETER"
        echo
        exit -1
    fi
fi

FLAGS+=" --port $USING_PORT_REST_API "
FLAGS+=" --model $MODEL_NAME "
FLAGS+=" --batch-size $BATCH_SIZE "

case $1 in
    "save")
        FLAGS+="--save-results "
        ACTION="Saving server response."
        ;;
    "check")
        ACTION="Validating server response against a file."
        FLAGS+="--check-results-from-file "
        ;;
    *)
        echo "No option passed. Please pass one of the following:" >&2
        echo -e "\t* save: to save the results from the server." >&2
        echo -e "\t\t$0 save" >&2
        echo -e -n "\t* check: to validate the response from the server against"
        echo -e " results saved in a file." >&2
        echo -e "\t\t$0 check" >&2
        echo
        exit -1
esac

echo "$ACTION"
python3 -O /home/chaoshan/serving/scripts/correctness_test.py $FLAGS
res=$?
echo "Done."
exit $res