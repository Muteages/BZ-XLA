import tensorflow.compat.v1 as tf
import tensorflow as tf2
import argparse
import shutil
import os
import numpy as np
from ops_meta import OPS_META
import inspect

parser = argparse.ArgumentParser(description="Tensorflow op model generator")
parser.add_argument('--save_model', action='store_true', help='Save model without execution', default=True)
parser.add_argument('--extract_ops', action='store_true', help='Extract operation names', default=False)
parser.add_argument('--op', type=str, help='Generate a specific model', default=None)
args = parser.parse_args()
save_model = args.save_model
extract_ops_flag = args.extract_ops

tf.disable_eager_execution()

export_base = "../models/optest"
DEFAULT_MODELS = [
    "models/model_DeepFM/1730800001",
    "models/model_DFFM/1730806856",
    "models/model_DLRM/1731305215",
    "models/model_DSSM/1730858967",
    "models/model_WIDE_AND_DEEP/1731296400",
]


def _is_shape_list_of_shapes(shape):
    return (
        isinstance(shape, (list, tuple))
        and len(shape) > 0
        and isinstance(shape[0], (list, tuple))
    )


def create_input(shape, name="input"):
    if save_model:
        return tf.placeholder(tf.float32, shape=shape, name=name)
    else:
        real_shape = [d if d is not None else 1 for d in shape]
        return tf.constant(np.random.rand(*real_shape).astype(np.float32), name=name)


def create_inputs(meta_shape):
    # Backward compatible:
    # - if meta_shape is [None,13,13] -> single tensor named "input"
    # - if meta_shape is [[...],[...]] -> list of tensors named input0,input1,...
    if _is_shape_list_of_shapes(meta_shape):
        return [create_input(s, name=f"input{i}") for i, s in enumerate(meta_shape)]
    return create_input(meta_shape, name="input")


def call_meta_fn(fn, inputs):
    # inputs may be a Tensor or list[Tensor]
    if isinstance(inputs, (list, tuple)):
        # Prefer calling with *inputs (supports lambda x,y or lambda *xs)
        try:
            return fn(*inputs)
        except TypeError:
            # If user still wrote fn expecting a single arg but provided multi inputs,
            # allow them to pass the list explicitly.
            return fn(inputs)
    else:
        return fn(inputs)


def build_signature(inputs, result):
    # inputs: Tensor or list[Tensor]
    if isinstance(inputs, (list, tuple)):
        input_map = {f"input{i}": tf.saved_model.utils.build_tensor_info(t) for i, t in enumerate(inputs)}
    else:
        input_map = {"input": tf.saved_model.utils.build_tensor_info(inputs)}

    # result can be Tensor or list/tuple/dict
    if isinstance(result, dict):
        output_map = {k: tf.saved_model.utils.build_tensor_info(v) for k, v in result.items()}
    elif isinstance(result, (list, tuple)):
        output_map = {f"result{i}": tf.saved_model.utils.build_tensor_info(t) for i, t in enumerate(result)}
    else:
        output_map = {"result": tf.saved_model.utils.build_tensor_info(result)}

    signature = tf.saved_model.signature_def_utils.build_signature_def(
        inputs=input_map,
        outputs=output_map,
        method_name=tf.saved_model.signature_constants.PREDICT_METHOD_NAME,
    )
    return signature


def write_default_models(file_obj):
    for model_path in DEFAULT_MODELS:
        file_obj.write(f"{model_path}\n")


def extract_ops():
    with open("models.list", "w") as f:
        write_default_models(f)
        for op_name in OPS_META:
            f.write(f"models/optest/model_{op_name}\n")
    print(f"[Completed] Saved model list in \"{export_base}/models.list\"")


def generate_and_save_model(model_name=None):
    models_to_generate = [model_name] if model_name else OPS_META.keys()

    if model_name is None and os.path.exists(export_base):
        print(f"[INFO] Generating all models: cleaning {export_base}")
        shutil.rmtree(export_base)
        os.makedirs(export_base)
    elif model_name:
        model_path = os.path.join(export_base, f"model_{model_name}")
        if os.path.exists(model_path):
            shutil.rmtree(model_path)

    cnt = 0
    for op_name in models_to_generate:
        meta = OPS_META.get(op_name)
        if not meta:
            print(f"[ERROR] Model '{op_name}' not found in OPS_META.")
            continue

        export_dir = os.path.join(export_base, f"model_{op_name}/1")

        with tf.Graph().as_default():
            inputs = create_inputs(meta["shape"])
            result = call_meta_fn(meta["fn"], inputs)

            if args.save_model:
                signature = build_signature(inputs, result)

                with tf.Session() as sess:
                    builder = tf.saved_model.builder.SavedModelBuilder(export_dir)
                    builder.add_meta_graph_and_variables(
                        sess,
                        [tf.saved_model.tag_constants.SERVING],
                        signature_def_map={
                            tf.saved_model.signature_constants.DEFAULT_SERVING_SIGNATURE_DEF_KEY: signature
                        },
                    )
                    builder.save()
                    print(f"[Processing] Saved model_{op_name}")
                    cnt += 1
            else:
                with tf.Session() as sess:
                    out = sess.run(result)
                print(f"{op_name} output shape:", np.shape(out))

    print("=================================")
    print(f"[Completed] Generated {cnt} / {len(models_to_generate)} models in \"{export_base}\"")


generate_and_save_model(args.op)
extract_ops()
