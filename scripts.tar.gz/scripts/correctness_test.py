#!/usr/bin/env python3

import os

import argparse

import pprint

import sys

from correctness_utils import *

parser = argparse.ArgumentParser("Correctness Test\n")

parser.add_argument(
    "--batch-size",
    type=int,
    nargs=1,
    default=[16],
    help="Select the batch size, i.e. the number of rows to be "
    "processed from the csv file.  (default: %(default)s)")
parser.add_argument("--port",
                    type=int,
                    nargs=1,
                    required=True,
                    help="Select the port to send requests.")
parser.add_argument("--rel-tol",
                    type=float,
                    nargs="?",
                    default=0.0,
                    help="Sets the relative tolerance for comparing results "
                    "returned from the server and the ones stored in a file. "
                    "Setting rel-tol to 0.05 means 5%% tolerance. "
                    "(default: %(default)s%%) which means the two values are "
                    "the same within about 6 decimal digits.")
parser.add_argument("--abs-tol",
                    type=float,
                    nargs="?",
                    default="0.0000000001",
                    help="Sets the absolute tolerance for comparing results"
                    " returned from the server and the ones stored in a file. "
                    " (default: %(default)s)")
parser.add_argument("--model",
                    type=str,
                    nargs=1,
                    required=True,
                    help="Set the model to run the tests.")
parser.add_argument("--json-file",
                    type=str,
                    default="data.json",
                    help="Sets the name for the json to be stored. "
                    " (default: %(default)s)")
parser.add_argument("--path-to-input-raw-file",
                    type=str,
                    default="./",
                    help="Sets the file path for the raw csv file."
                    " (default: %(default)s, i.e. current location)")
parser.add_argument("--raw-file",
                    type=str,
                    default="eval.csv",
                    help="File name with raw data to send to the server. "
                    " (default: %(default)s)")
parser.add_argument(
    "--print-results",
    action="store_true",
    help="Prints retults comapring the respons from the server "
    "to the values of the json reference.")
parser.add_argument("--print-results-raw",
                    action="store_true",
                    help="Prints all the values returned from the server.")
parser.add_argument("--save-results",
                    action="store_true",
                    help="Save the results from the server into a file "
                    "(results.json)")
parser.add_argument("--check-results-from-file",
                    type=str,
                    nargs="?",
                    const="results.json",
                    help="Compares the current results to results stored in a "
                    "file (default: %(const)s).")
parser.add_argument("--no-print-failed-list",
                    action="store_false",
                    dest="print_failed_list",
                    help="Disable printing failed elements list")

args = parser.parse_args()


def main():
    # Check if http_proxy is set
    http_proxy = os.environ.get('http_proxy')
    if http_proxy is not None:
        print("The enviroment variable http_proxy is set, please unset it.")
        print("HINT:")
        print("run:")
        print("\tunset http_proxy")
        exit(-1)

    batch_size = args.batch_size[0]
    inputs, outputs = get_metadata(batch_size, args.port[0], args.model[0])

    if __debug__:
        print("Inputs")
        pprint.pprint(inputs)

    if __debug__:
        print("Outputs")
        pprint.pprint(outputs)

    # Generate file to send to the sever if saving the result to a file
    if (args.check_results_from_file is None):
        generate(batch_size, args.json_file, inputs)

    # Send request to the server using the generated file
    command = ("curl -d @{} -H".format(args.json_file) +
               "\"Content-Type: application/json\" " + "-X POST " +
               "http://localhost:{}/v1/models/{}:predict".format(
                   args.port[0], args.model[0]))

    stdout, stderr = run_command(cmd=command)
    if not stdout:
        print("The server response was empty.")
        print(
            "Please check the server is running and the port number is correct."
        )
        exit(-1)

    # Check server response
    server_response = json.loads(stdout)
    if "error" in server_response:
        print("Something went wrong.")
        print("The error is:")
        print(server_response['error'])
        print()
        exit(-1)

    if (args.print_results_raw):
        pprint.pprint(stdout)

    formatted_sever_response = format_sever_response(server_response)

    if (args.save_results):
        try:
            with open("results.json", "w") as f:
                f.write(json.dumps(formatted_sever_response))
        except FileNotFoundError:
            print(
                "Error: The file {args.check_results_from_file} does not exist."
            )
        except PermissionError:
            print("Error: You do not have permission to create this file.")
        except Exception as e:
            print("Something went wrong when creating the file:")
            print("\t", args.check_results_from_file)
            print(e)
            exit(-1)

    if (args.check_results_from_file):
        is_equal = compare_with_file(args.check_results_from_file,
                          formatted_sever_response,
                          outputs,
                          atol=args.abs_tol,
                          rtol=args.rel_tol,
                          print_list=args.print_failed_list)
        
        if is_equal:
            sys.exit(0)
        else:
            sys.exit(1)


if __name__ == "__main__":
    main()
