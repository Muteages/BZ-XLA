import numpy as np
import json
import subprocess
import pprint

import random
import string


def create_random_array(dims, dtype, str_len=8):

    if dtype in ["DT_STRING"]:
        # Create a flat list of random strings
        total_elements = np.prod(dims)
        chars = string.ascii_letters + string.digits

        random_strings = [
            ''.join(random.choices(chars, k=str_len))
            for _ in range(total_elements)
        ]

        random_strings = [f"{s}" for s in random_strings]

        # Reshape the flat list into the desired dimensions
        results = np.array(random_strings).reshape(dims)

    elif dtype in ["DT_INT32", "DT_INT64"]:
        data_type = np.int32 if dtype == "DT_INT32" else np.int64
        results = np.random.randint(0, 100, size=dims, dtype=data_type)

    elif dtype == "DT_BOOL":
        results = np.random.choice([True, False], size=dims)

    elif dtype in ["DT_FLOAT", "DT_DOUBLE"]:
        data_type = np.float32 if dtype == "DT_FLOAT" else np.float64
        results = np.random.rand(*dims).astype(data_type)
    else:
        raise TypeError("The provided data type is not supported yet: ", dtype)

    return results.tolist()


def print_results_array(a, b, print_all=False):
    # Escape Codes for formatting
    RED = "\033[91m"
    RESET = "\033[0m"

    header = (f" {'Saved Value':<23} | {'Server Response':<23} | "
        f"{'Difference':<23}")
    print(header)
    for val_a, val_b in zip(a.ravel(), b.ravel()):
        if val_a != val_b:
            # Print mismatched elements in red
            va = f"{RED}{val_a:<23}{RESET}"
            vb = f"{RED}{val_a:<23}{RESET}"
            diff = f"{RED}{val_a - val_b:<23}{RESET}"
            print(f" {va} | {vb} | {diff}")
        elif (print_all):
            # Print identical elements normally
            print(f" {val_a:<23} | {val_b:<23}")
    print()


def run_command(cmd):
    """Run a shell command and return its output."""
    process = subprocess.Popen(cmd,
                               shell=True,
                               stdout=subprocess.PIPE,
                               stderr=subprocess.PIPE)
    if __debug__:
        print("Command: ", cmd)
    try:
        stdout, stderr = process.communicate()
        return stdout.decode('utf-8'), stderr.decode('utf-8')
    except UnicodeDecodeError:
        print("Something went wrong: UnicodeDecodeError")
        print("HINT: check the port number is correct.")
        exit(-1)
    except Exception as e:
        print("Something went wrong with the response fromt the server:")
        print(e)
        exit(-1)


def compare_with_file(saved_file, response_from_the_server, outputs, atol,
                      rtol, print_list):
    try:
        with open(saved_file, "r") as f:
            saved_results = json.load(f)
            return compare_tf_lists(saved_results, response_from_the_server,
                                    outputs, atol, rtol, print_list)
    except FileNotFoundError:
        print("The file {} was not found.".format(saved_file))
        print(
            "HINT: Generate {} first by running the script with --save-results."
            .format(saved_file))
        exit(-1)
    except IOError:
        print(
            "An error occurred while reading the file {}.".format(saved_file))
        exit(-1)


def get_metadata(batch_size, port, model):
    # Get metadata from the server
    command = "curl -X GET http://localhost:{}/v1/models/{}/metadata".format(
        port, model)
    stdout, stderr = run_command(cmd=command)

    if not stdout:
        print("The server response was empty.")
        print("Check that the server is running.")
        exit(-1)

    metadata = json.loads(stdout)
    if "error" in metadata:
        print()
        print("Something went wrong:")
        print("\t", metadata["error"])
        print()
        exit(-1)

    if __debug__:
        print("Metadata:")
        pprint.pprint(metadata)

    sig_def = metadata["metadata"]["signature_def"]["signature_def"]
    inputs = sig_def["serving_default"]["inputs"]

    outputs = sig_def["serving_default"]["outputs"]
    key = list(outputs.keys())[0]
    # Depending on the model the key for outpus could be different
    dimensions = outputs[key]["tensor_shape"]["dim"]
    dtype = outputs[key]["dtype"]

    output_dims = []
    for dim in dimensions:
        int_dim = int(dim["size"])
        d = batch_size if int_dim == -1 else int_dim
        output_dims.append(d)

    outputs = {"dtype": dtype, "dims": output_dims}
    return inputs, outputs


def generate(batch_size, json_file, inputs):

    # Create a dictionary with shapes and types
    shapes = {}
    for key in inputs:
        shape = []
        inpput_type = inputs[key]["dtype"]
        if __debug__:
            print("key: ", key)
            print("Type: ", inpput_type)
        dimensions = inputs[key]["tensor_shape"]["dim"]
        for dim in dimensions:
            dim_size = int(dim["size"])
            int_dim = batch_size if dim_size == -1 else dim_size
            shape.append(int_dim)

        shapes[key] = {"shape": shape, "type": inpput_type}

    entries = {}
    # Create a dictionary filled with the correct inputs
    for key in shapes:
        dtype = shapes[key]["type"]
        numbers = create_random_array(shapes[key]["shape"], dtype)
        entries[key] = numbers

    # Save the entries in a json file
    json_data = {"inputs": entries}
    with open(json_file, 'w') as f:
        data = json.dumps(json_data)
        f.write(data)


def compare_tf_lists(saved_results, response_from_the_server, description,
                     atol, rtol, print_list):
    # 1. Convert TF dtype string to NumPy dtype
    dtypes = {
        'DT_FLOAT': np.float32,
        'DT_DOUBLE': np.float64,
        'DT_INT32': np.int32,
        'DT_INT64': np.int64
    }
    dtype = dtypes.get(description['dtype'], np.float32)

    # 2. Convert lists to NumPy arrays with the specific dtype
    try:
        array_saved_results = np.array(saved_results["result"], dtype=dtype)
        array_response_from_the_server = np.array(
            response_from_the_server["result"], dtype=dtype)
    except ValueError as e:
        print(f"Data conversion error: {e}")
        exit(-1)

    # 3. Check Dimensions (Shape)
    if array_response_from_the_server.shape != array_saved_results.shape:
        print(
            (f"Shape . Expected {array_saved_results.shape}, "
             f"got {array_response_from_the_server.shape}.\n"
             f"Check that the saved response is the same size as the check.\n"
             f"HINT: re run the script to save the response.\n"))
        # TODO: Comment out for now to avoid early exit.
        # Shape mismatch currently occurs due to the unresolved "977" issue.
        # exit(-1)
    else:
        print(f"Got correct shape: {array_saved_results.shape}")

    # Trim server results to match the saved array shape.
    n = array_saved_results.shape[0]
    array_trimmed_server_results = array_response_from_the_server[:n]

    # 4. Check for Equality within Delta
    # np.allclose handles the absolute difference check: |a - b| <= delta
    is_equal = np.allclose(array_saved_results,
                           array_trimmed_server_results,
                           rtol=rtol,
                           atol=atol)
    if is_equal:
        print("Correctness test passed.")
    else:
        a = array_saved_results
        b = array_trimmed_server_results
        diff = np.where(np.abs(a - b) > atol)
        print("Correctness test Failed.")
        if not print_list:
            print("Printing a list of elements that fail:")
            for idx in diff[0]:
                if isinstance(a[idx], np.ndarray):
                    print_results_array(a[idx], b[idx])
                else:
                    print(
                        f"Index {idx}: a[{idx}]={a[idx]}, "
                        f"b[{idx}]={b[idx]}, Diff={a[idx]-b[idx]}"
                    )
    return is_equal


def format_sever_response(server_response):
    if __debug__:
        print("server_response: ", server_response)

    # This is done because the key depends on the model
    key = list(server_response.keys())[0]
    result = {"result": server_response[key]}
    return result
